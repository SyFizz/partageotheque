<?php

namespace App\Http\Controllers;

class SamuelController extends Controller
{
    public function index()
    {

    }
}
