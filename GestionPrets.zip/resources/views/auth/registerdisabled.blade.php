<x-guest-layout>
    <div class="py-12">
        <div class="text-5xl p-6 text-gray-900 text-center font-bold">
            {{ __("Pour avoir un compte, contactez le référent informatique ou le DDFPT.") }}
        </div>
    </div>
</x-guest-layout>
